package com.distribuida;
import com.distribuida.db.Book;
import com.distribuida.servicios.ServicioBook;
import com.google.gson.Gson;
import jakarta.annotation.PostConstruct;
import jakarta.transaction.Transactional;
import jakarta .inject.Inject;
import jakarta.enterprise.inject.se.SeContainer;
import jakarta.enterprise.inject.se.SeContainerInitializer;
import spark.Request;
import spark.Response;
import org.json.JSONObject;
import org.json.JSONArray;




import java.util.List;

import static spark.Spark.*;
public class Principal {
/*
    static List<Book> listarLibros(Request req, Response res) {
        var servicio = container.select(ServicioBook.class)
                .get();
        res.type("application/json");

        return servicio.findAll();
    }

    static Book buscarLibro(Request req, Response res) {
        var servicio = container.select(ServicioBook.class)
                .get();
        res.type("application/json");

        String _id = req.params(":id");

        var book =  servicio.findById(Integer.valueOf(_id));

        if(book==null) {
            // 404
            halt(404, "Libro no encontrado");
        }

        return book;
    }

    public static Book actualizarLibro(Request req, Response res) {

        var servicio=container.select(ServicioBook.class).get();
        res.type("application/json");
        String _id=req.params(":id");
        String requestBody=req.body();

        Gson gson= new Gson();
        Book book=gson.fromJson(requestBody,Book.class);
        book.setId(Integer.valueOf(_id));
        servicio.actualizar(book);

        if(book==null){
            halt(404, "Libro no encontrado");
        }
        return  book;
    }

    public static Boolean eliminarLibro(Request req, Response res) {
        res.type("application/json");


        String idStr = req.params(":id");
        Integer id = Integer.valueOf(idStr);

        var servicio = container.select(ServicioBook.class).get();


        boolean eliminado = servicio.borrar(id);

        if (eliminado) {

            return true;
        } else {

            res.status(404);
            return false;
        }
    }

    static Book crearLibro(Request req, Response res) {
        var servicio = container.select(ServicioBook.class).get();
        res.type("application/json");
        Gson gson = new Gson();
        var nuevoBook = gson.fromJson(req.body(), Book.class);
        servicio.insertar(nuevoBook);


        return nuevoBook;
    }
    */

    public static String actualizarLibro(Request req, Response res) {
        var servicio = container.select(ServicioBook.class).get();
        res.type("application/json");

        String _id = req.params(":id");
        String requestBody = req.body();

        JSONObject jsonObject = new JSONObject(requestBody);
        Book book = new Book();
        book.setId(Integer.valueOf(_id));
        servicio.actualizar(book);

        if (book == null) {
            halt(404, "Libro no encontrado");
        }

        return jsonObject.toString();
    }


    public static List<Book> listarLibros(Request req, Response res) {
        var servicio = container.select(ServicioBook.class).get();
        res.type("application/json");
        return servicio.findAll();
    }
    public static String buscarLibro(Request req, Response res) {
        var servicio = container.select(ServicioBook.class).get();
        res.type("application/json");

        String _id = req.params(":id");
        Book book = servicio.findById(Integer.valueOf(_id));

        if (book == null) {
            halt(404, "Libro no encontrado");
        }

        JSONObject jsonObject = new JSONObject(book);
        return jsonObject.toString();
    }
    public static String eliminarLibro(Request req, Response res) {
        res.type("application/json");

        String idStr = req.params(":id");
        Integer id = Integer.valueOf(idStr);

        var servicio = container.select(ServicioBook.class).get();

        boolean eliminado = servicio.borrar(id);

        if (eliminado) {
            JSONObject response = new JSONObject();
            response.put("mensaje", "Libro eliminado correctamente");
            return response.toString();
        } else {
            res.status(404);
            JSONObject response = new JSONObject();
            response.put("error", "Libro no encontrado");
            return response.toString();
        }
    }
    public static String crearLibro(Request req, Response res) {
        var servicio = container.select(ServicioBook.class).get();
        res.type("application/json");

        // Convertir el cuerpo de la solicitud a un JSONObject
        String requestBody = req.body();
        JSONObject jsonObject = new JSONObject(requestBody);

        // Crear un nuevo objeto Book y llenarlo con los datos del JSONObject
        Book nuevoBook = new Book();

        servicio.insertar(nuevoBook);

        // Convertir el nuevo libro a JSON y devolverlo
        return jsonObject.toString();
    }




    static SeContainer container;

    public static void main(String[] args) {

        container = SeContainerInitializer
                .newInstance()
                .initialize();

        port(8080);


        /* GSON
        Gson gson = new Gson();
        get("/books", Principal::listarLibros, gson::toJson);
        get("/books/:id", Principal::buscarLibro, gson::toJson);
        post("/books",Principal::crearLibro, gson::toJson);
        delete("/books/:id", Principal::eliminarLibro, gson::toJson);
        put("/books/:id", Principal::actualizarLibro, gson::toJson);
*/


        // USANDO MOTOR JSON
        get("/books", (req, res) -> {
            List<Book> libros = Principal.listarLibros(req, res);
            JSONArray jsonArray = new JSONArray(libros);
            return jsonArray.toString();
        });

        get("/books/:id", (req, res) -> {
            String libroJson = Principal.buscarLibro(req, res);
            return libroJson;
        });



        delete("/books/:id", (req, res) -> {
            String respuestaJson = Principal.eliminarLibro(req, res);
            return respuestaJson;
        });


        post("/books", (req, res) -> {
            String nuevoLibroJson = Principal.crearLibro(req, res);
            return nuevoLibroJson;
        });

        put("/books/:id", (req, res) -> {
            String libroActualizadoJson = Principal.actualizarLibro(req, res);
            return libroActualizadoJson;
        });
    }
}
