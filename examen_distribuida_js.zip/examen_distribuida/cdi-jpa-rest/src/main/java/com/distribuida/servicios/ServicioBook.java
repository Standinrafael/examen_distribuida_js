package com.distribuida.servicios;

import com.distribuida.db.Book;
import java.util.List;

public interface ServicioBook {

    void insertar(Book b);

    List<Book> findAll();

    Book findById (Integer id);

    boolean borrar(Integer id);

    boolean actualizar (Book book);
}
