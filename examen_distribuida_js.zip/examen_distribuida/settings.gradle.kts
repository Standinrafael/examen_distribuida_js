rootProject.name = "examen_distribuida"
include("cdi-jpa-rest")
